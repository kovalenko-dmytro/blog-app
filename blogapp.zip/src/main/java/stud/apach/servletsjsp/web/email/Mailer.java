package stud.apach.servletsjsp.web.email;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Properties;

public class Mailer {

    public void send(String from, String to, String subject, String emailContent, String login, String password) {


        // Get system properties
        Properties properties = System.getProperties();

        // Setup mail server

        properties.put("mail.smtp.host", "smtp.gmail.com");
        properties.put("mail.port", "587");
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true");


        // Get the default Session object.
        Session session = Session.getDefaultInstance(properties,
                new javax.mail.Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(login, password);
                    }
                });

        try {
            // Create a default MimeMessage object.
            MimeMessage mailMessage = new MimeMessage(session);

            // Set From: header field of the header.
            mailMessage.setFrom(new InternetAddress(from));

            // Set To: header field of the header.
            mailMessage.addRecipient(Message.RecipientType.TO, new InternetAddress(to));

            // Set Subject: header field
            mailMessage.setSubject(subject);

            // Now set the actual message
            mailMessage.setText(emailContent);

            // Send message
            Transport.send(mailMessage);

        } catch (MessagingException mex) {
            mex.printStackTrace();
        }

    }
}
