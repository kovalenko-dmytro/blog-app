package stud.apach.servletsjsp.web.validators;

import stud.apach.servletsjsp.model.beans.UserBean;
import stud.apach.servletsjsp.model.dao.entities.User;

import java.util.Map;

public class LoginValidator {

    public static User checkUser(Map loginParams) {

        return new UserBean().getUserById(1);
    }
}
