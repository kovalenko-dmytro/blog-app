package stud.apach.servletsjsp.web.auth;

import stud.apach.servletsjsp.model.dao.factory.DBDAOFactory;

import java.util.Map;
import java.sql.*;

import javax.security.auth.spi.LoginModule;
import javax.security.auth.*;
import javax.security.auth.callback.*;
import javax.security.auth.login.*;


public class UserLoginModule implements LoginModule {

    //These instance variables will be initialized by the
    //initialize( ) method
    private CallbackHandler handler;
    private Subject subject;
    private Map sharedState;
    private Map options;

    private boolean loginPassed = false;


    public void initialize(Subject subject, CallbackHandler handler,
                           Map sharedState, Map options){

        this.subject = subject;
        this.handler = handler;
        this.sharedState = sharedState;
        this.options = options;

    }

    public boolean login() throws LoginException {

        String email = "";
        String password = "";


        Connection conn;
        Statement stmt;
        ResultSet rs;

        boolean passed = false;

        try{

            //Create the CallBack array to pass to the
            //CallbackHandler.handle( ) method
            Callback[] callbacks = new Callback[2];

            //Don't use null arguments with the TextInputCallback constructor!
            callbacks[0] = new NameCallback("loginEmail:");

            //Don't use null arguments with PasswordCallback!
            callbacks[1] = new PasswordCallback("loginPassword:", false);

            handler.handle(callbacks);

            //Get the email and password from the CallBacks
            NameCallback emailCall = (NameCallback) callbacks[0];

            email = emailCall.getName();

            PasswordCallback passCall = (PasswordCallback) callbacks[1];

            password = new String (passCall.getPassword());

            //The SQL for checking a name and password in a table named
            //athlete
            String sqlEmail = "SELECT * FROM users WHERE email ='" + email + "'";

            String sqlPassword = "SELECT * FROM users WHERE password ='" + password + "'";

            //Get a Connection from the connection pool
            conn = DBDAOFactory.getInstance().createConnection();

            stmt = conn.createStatement( );

            //Check the email
            rs = stmt.executeQuery(sqlEmail);

            //If the ResultSet has rows, then the username was
            //correct and next( ) returns true
            passed = rs.next();

            rs.close( );

            if (!passed){

                loginPassed = false;
                throw new FailedLoginException(
                        "The user email was not successfully authenticated");

            }

            //Check the password
            rs = stmt.executeQuery(sqlPassword);

            passed = rs.next( );

            if (!passed){

                loginPassed = false;
                throw new FailedLoginException(
                        "The password was not successfully authenticated");

            } else {

                loginPassed = true;
                return true;

            }

        } catch (Exception e){

            throw new LoginException(e.getMessage( ));

        }

    } //login

    public boolean commit() throws LoginException {

        //We're not doing anything special here, since this class
        //represents a simple example of login authentication with JAAS.
        //Just return what login() returned.
        return loginPassed;
    }

    public boolean abort() throws LoginException {

        //Reset state
        boolean bool = loginPassed;
        loginPassed = false;

        return bool;
    }

    public boolean logout() throws LoginException {

        //Reset state
        loginPassed = false;
        return true;

    } //logout


}
