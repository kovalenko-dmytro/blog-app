package stud.apach.servletsjsp.web.auth;

import javax.security.auth.callback.*;
import javax.servlet.ServletRequest;

public class WebCallbackHandler implements CallbackHandler {

    private String loginEmail;
    private String loginPassword;

    public WebCallbackHandler(ServletRequest request){

        loginEmail = request.getParameter("loginEmail");
        loginPassword = request.getParameter("loginPassword");

    }

    public void handle(Callback[] callbacks) throws java.io.IOException,
            UnsupportedCallbackException {

        //Add the email and password from the request parameters to
        //the Callbacks
        for (int i = 0; i < callbacks.length; i++){

            if (callbacks[i] instanceof NameCallback){

                NameCallback emailCall = (NameCallback) callbacks[i];

                emailCall.setName(loginEmail);

            } else if (callbacks[i] instanceof PasswordCallback){

                PasswordCallback passCall = (PasswordCallback) callbacks[i];

                passCall.setPassword(loginPassword.toCharArray( ));

            } else{

                throw new UnsupportedCallbackException (callbacks[i],
                        "The CallBacks are unrecognized in class: " + getClass( ).
                                getName( ));

            }

        } //for
    } //handle

}
