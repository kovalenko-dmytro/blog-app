package stud.apach.servletsjsp.model.dao.entities;

import java.io.*;

public interface Entity extends Serializable {	
		
}
